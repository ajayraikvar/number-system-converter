<div class="nsc-wrapper">
    <svg class="nsc-bg-svg" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid slice">
        <defs>
            <linearGradient id="nscGradient" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#4a90e2"/>
                <stop offset="100%" stop-color="#7b61ff"/>
            </linearGradient>
        </defs>
        <circle cx="400" cy="200" r="250" fill="url(#nscGradient)" opacity="0.15" />
    </svg>

    <div class="nsc-container">
        <div class="nsc-header">
            <h2>🔢 Number System Converter</h2>
            <button class="nsc-toggle" onclick="toggleTheme()">🌓</button>
        </div>

        <form id="nsc-form">
            <div class="nsc-group">
                <label>Enter Number</label>
                <input type="text" id="inputValue" placeholder="e.g. 1111 or 15" required>
            </div>

            <div class="nsc-group">
                <label>Convert From</label>
                <select id="inputBase">
                    <option value="2">Binary</option>
                    <option value="10" selected>Decimal</option>
                    <option value="8">Octal</option>
                    <option value="16">Hexadecimal</option>
                </select>
            </div>

            <div class="nsc-group">
                <button type="button" onclick="convertNumber()">Convert 🚀</button>
            </div>

            <div id="nsc-results" class="nsc-results"></div>
        </form>
    </div>
</div>

<script>
function convertNumber() {
    const val = document.getElementById('inputValue').value.trim();
    const base = parseInt(document.getElementById('inputBase').value);
    const resBox = document.getElementById('nsc-results');
    let decimal;

    try {
        decimal = parseInt(val, base);
        if (isNaN(decimal)) throw "Invalid input";

        const renderResult = (label, value) => `
            <div class="nsc-result">
                <strong>${label}:</strong> <span>${value}</span>
                <button onclick="copyToClipboard('${value}')">📋</button>
            </div>`;

        resBox.innerHTML = [
            renderResult("Binary", decimal.toString(2)),
            renderResult("Decimal", decimal.toString(10)),
            renderResult("Octal", decimal.toString(8)),
            renderResult("Hexadecimal", decimal.toString(16).toUpperCase()),
        ].join('');
    } catch (e) {
        resBox.innerHTML = '<div class="nsc-error">❌ Invalid input or format</div>';
    }
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert("Copied to clipboard: " + text);
    });
}

function toggleTheme() {
    document.body.classList.toggle('nsc-dark');
}
</script>
